

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger no-mb">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div>
    <p class="titulo">SEF > Lista de Examenes</p>
</div>

<div class="contenedor-tarjetas">
    <table class="table tabla-consultar">
        <thead>
            <tr class="tabla-consultar">
                <th scope="col">Examen</th>
                <th scope="col">calificacion</th>
                <th scope="col">Fecha de realizacion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $examenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tabla-consultar">
                <td><?php echo e($examen->titulo); ?></td>
                <td><?php echo e($examen->pivot->calificacion); ?></td>
                <td><?php echo e($examen->pivot->fechaAplicacion); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/evaluacion/listar_examenes_realizados.blade.php ENDPATH**/ ?>