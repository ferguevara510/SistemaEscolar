

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Examenes</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="line-search">
    <section>
        <form method="get" action="<?php echo e(route('estudianteList')); ?>">		    
            <input class="line-search-input" type="search" name="busqueda" placeholder="Nombre estudiante">		    	
            <button class="btn-opcion-buscar" type="submit"><a class="texto-link">Buscar 🔍</a></button>
        </form>
    </section>
</div>
<div class="btn-registrar">
    <button type="button" class="btn-opcion"><a class="texto-link" href="<?php echo e(route('examenIndex')); ?>">Registrar ➕</a></button>
</div>
<div class="contenedor-tarjetas">
    <table class="table tabla-consultar">
        <thead>
            <tr class="tabla-consultar">
                <th scope="col">Examen</th>
                <th scope="col">Preguntas</th>
                <th scope="col">Resultados</th>
                <th scope="col">Modificar</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $examenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tabla-consultar">
                <td><?php echo e($examen->titulo); ?></td>
                <td><?php echo e($examen->numeroPreguntas); ?></td>
                <td><button type="button" class="btn-opcion"><a class="texto-link" href="<?php echo e(route('examenResultados', $examen->id)); ?>">Resultados ✍️</a></button></td>
                <td><button type="button" class="btn-opcion"><a class="texto-link" href="<?php echo e(route('examenShow', $examen->id)); ?>">Modificar ✍️</a></button></td>
                <td>
                    <form method="post" action="<?php echo e(route('examenDelete', $examen->id)); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-opcion btn-opcion-color"><a class="texto-link">Eliminar 🗑️</a></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/examen/consultar_examen.blade.php ENDPATH**/ ?>