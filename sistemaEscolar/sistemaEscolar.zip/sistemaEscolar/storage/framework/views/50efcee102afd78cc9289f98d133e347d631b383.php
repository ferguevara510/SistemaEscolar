

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">
<div class="container-registro mt-5">

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('examenStorage')); ?>">

        <?php echo csrf_field(); ?>
        <div class="form-group form-registro">
            <input type="hidden" value="<?php echo e($profesorId); ?>" name="profesor_id" id="profesorId">
        </div>
        
        <div class="form-group form-registro">
            <label>Titulo Examen</label>
            <input type="text" class="form-control $errors->has('titulo') ? 'error' : '' " name="titulo">
            <?php if($errors->has('titulo')): ?>
            <div class="error">
                <?php echo e($errors->first('titulo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Numero de preguntas</label>
            <input type="number" class="form-control  $errors->has('numeroPreguntas') ? 'error' : '' " name="numeroPreguntas" id="numeroPreguntas">
            <?php if($errors->has('numeroPreguntas')): ?>
            <div class="error">
                <?php echo e($errors->first('numeroPreguntas')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Registrar ➕" class="btn-opcion btn-opcion-color">
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/examen/registrar_examen.blade.php ENDPATH**/ ?>