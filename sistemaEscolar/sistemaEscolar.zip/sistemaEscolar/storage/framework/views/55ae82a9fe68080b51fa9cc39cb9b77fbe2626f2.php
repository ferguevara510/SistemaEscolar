

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">
<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('preguntaStorage')); ?>">

        <?php echo csrf_field(); ?>
        <div class="form-group form-registro">
            <input type="hidden" value="<?php echo e($examenId); ?>" name="examen_id" id="examenId">
        </div>
        
        <div class="form-group form-registro">
            <label>Pregunta</label>
            <input type="text" class="form-control $errors->has('descripcion') ? 'error' : '' " name="descripcion">
            <?php if($errors->has('descripcion')): ?>
            <div class="error">
                <?php echo e($errors->first('descripcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Registrar ➕" class="btn-opcion btn-opcion-color">
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/pregunta/registrar_pregunta.blade.php ENDPATH**/ ?>