<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'SEF')); ?></title>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="preload" href="<?php echo e(asset('css/colores.css')); ?>" as="style">
    <link rel="stylesheet" href="<?php echo e(asset('css/colores.css')); ?>">
    <link rel="preload" href="<?php echo e(asset('css/header.css')); ?>" as="style">
    <link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">    
</head>
<div class="logo">
    <a href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset ('img/SEF.png')); ?>">
    </a>
</div><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/layouts/encabezado/encabezado.blade.php ENDPATH**/ ?>