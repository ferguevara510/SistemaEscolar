

<?php $__env->startSection('content'); ?>
    <div>
        <p class="titulo">SEF > Examen</p>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($pregunta->descripcion); ?></h5>
            <?php if(intval($total) == intval($index) + 1): ?>
                <form action="<?php echo e(route('examenFinish')); ?>" method="POST">
            <?php else: ?>
                <form action="<?php echo e(route('respuestaExamen', $index)); ?>" method="POST">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $pregunta->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="respuesta_id" id="respuesta_id"
                            value="<?php echo e($respuesta->id); ?>" />
                        <label class="form-check-label" for="respuesta_id">
                            <?php echo e($respuesta->descripcion); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(intval($total) == intval($index) + 1): ?>
                    <div class="mt-5 div-btn-submit">
                        <input type="submit" name="send" value="Finalizar" class="btn-opcion btn-opcion-color">
                    </div>
                <?php else: ?>
                    <div class="mt-5 div-btn-submit">
                        <input type="submit" name="send" value="Siguiente" class="btn-opcion btn-opcion-color">
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menus.app_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/evaluacion/responder_pregunta.blade.php ENDPATH**/ ?>