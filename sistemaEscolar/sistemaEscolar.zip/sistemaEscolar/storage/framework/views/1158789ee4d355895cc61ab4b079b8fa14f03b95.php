

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Examenes > Modificar datos Examenes</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('preguntaEdit', $pregunta->id)); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group form-registro">
            <input type="hidden" value="<?php echo e($pregunta->examen_id); ?>" name="examen_id" id="examenId">
        </div>

        <div class="form-group form-registro">
            <label>Descripcion</label>
            <input value="<?php echo e($pregunta->descripcion); ?>" type="text" class="form-control  $errors->has('descripcion') ? 'error' : '' " name="descripcion" id="descripcion">
            <?php if($errors->has('descripcion')): ?>
            <div class="error">
                <?php echo e($errors->first('descripcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Modificar ✍️" class="btn-opcion btn-opcion-color">
        </div>
    </form>
    
    <div class="contenedor-tarjetas">
        <table class="table tabla-consultar">
            <thead>
                <tr class="tabla-consultar">
                    <th scope="col">cheched</th>
                    <th scope="col">Respuesta</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Marcar como correcta</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="tabla-consultar">
                    <td><input type="checkbox" onclick="return false;" <?php echo e($respuesta->esCorrecto ? 'checked': ''); ?>/></td>
                    <td><?php echo e($respuesta->descripcion); ?></td>
                    <td>
                        <form method="post" action="<?php echo e(route('respuestaDelete', $respuesta->id)); ?>">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn-opcion btn-opcion-color"><a class="texto-link">Eliminar 🗑️</a></button>
                        </form>
                    </td>
                    <td>
                        <form method="post" action="<?php echo e(route('respuestaCorrecta', $respuesta->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn-opcion btn-opcion-color"><a class="texto-link">Marcar ✔</a></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if(count($respuestas) < 4): ?>
        <div class="container-registro mt-5">

            <form method="post" action="<?php echo e(route('respuestaStorage')); ?>">

                <?php echo csrf_field(); ?>
                <div class="form-group form-registro">
                    <input type="hidden" value="<?php echo e($pregunta->id); ?>" name="pregunta_id" id="preguntaId">
                </div>
                
                <div class="form-group form-registro">
                    <label>Respuesta</label>
                    <input type="text" class="form-control $errors->has('descripcion') ? 'error' : '' " name="descripcion">
                    <?php if($errors->has('descripcion')): ?>
                    <div class="error">
                        <?php echo e($errors->first('descripcion')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="div-btn-submit">
                    <input type="submit" name="send" value="Registrar Respuesta ➕" class="btn-opcion btn-opcion-color">
                </div>
            </form>
        </div>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/pregunta/modificar_pregunta.blade.php ENDPATH**/ ?>