

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Estudiantes > Modificar datos Estudiante</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('estudanteEdit', $estudiante->id)); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group form-registro">
            <label>Nombre Estudiante</label>
            <input value="<?php echo e($estudiante->nombreEstudiante); ?>" type="text" class="form-control  $errors->has('nombreEstudinte') ? 'error' : '' " name="nombreEstudiante" id="nombreEstudiante">
            <?php if($errors->has('nombreEstudiante')): ?>
            <div class="error">
                <?php echo e($errors->first('nombreEstudiante')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Apellidos Estudiante</label>
            <input value="<?php echo e($estudiante->apelldosEstudiante); ?>" type="text" class="form-control  $errors->has('apellidosEstudinte') ? 'error' : '' " name="apellidosEstudiante" id="apellidosEstudiante">
            <?php if($errors->has('apellidosEstudiante')): ?>
            <div class="error">
                <?php echo e($errors->first('apellidosEstudiante')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Matricula</label>
            <input value="<?php echo e($estudiante->matricula); ?>" type="text" class="form-control  $errors->has('matricula') ? 'error' : '' " name="matricula" id="matricula">
            <?php if($errors->has('matricula')): ?>
            <div class="error">
                <?php echo e($errors->first('matricula')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Correo Institucional</label>
            <input value="<?php echo e($estudiante->correoInstitucional); ?>" type="email" class="form-control  $errors->has('correoInstitucional') ? 'error' : '' " name="correoInstitucional"
                id="correoInstitucional">
            <?php if($errors->has('correoInstitucional')): ?>
            <div class="error">
                <?php echo e($errors->first('correoInstituional')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Contraseña Estudiante</label>
            <input value="<?php echo e($estudiante->contrasena); ?>" type="text" class="form-control  $errors->has('contrasena') ? 'error' : '' " name="contrasena" id="contrasena">
            <?php if($errors->has('nombreEstudiante')): ?>
            <div class="error">
                <?php echo e($errors->first('nombreEstudiante')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Licenciatura</label>
            <select class="form-control  $errors->has('licenciatura') ? 'error' : '' " name="licenciatura" id="licenciatura">
                <?php $__currentLoopData = $enumLicenciatura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licenciatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($estudiante->licenciatura === $licenciatura): ?>
                <option selected value="<?php echo e($licenciatura); ?>"><?php echo e($licenciatura); ?></option>
                <?php else: ?>
                <option value="<?php echo e($licenciatura); ?>"><?php echo e($licenciatura); ?></option>
                <?php endif; ?>          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('licenciatura')): ?>
            <div class="error">
                <?php echo e($errors->first('licenciatura')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Area Academica</label>
            <select class="form-control  $errors->has('areaAcademmica') ? 'error' : '' " name="areaAcademica" id="areaAcademica">
                <?php $__currentLoopData = $enumAreaAcademica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $areaAcademica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                <?php if($estudiante->areaAcademica === $areaAcademica): ?>
                <option selected value="<?php echo e($areaAcademica); ?>"><?php echo e($areaAcademica); ?></option>
                <?php else: ?>
                <option value="<?php echo e($areaAcademica); ?>"><?php echo e($areaAcademica); ?></option>
                <?php endif; ?>          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('areaAcademica')): ?>
            <div class="error">
                <?php echo e($errors->first('areaAcademica')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Entidad</label>
            <select class="form-control  $errors->has('entidad') ? 'error' : '' " name="entidad" id="entidad">
                <?php $__currentLoopData = $enumEntidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                <?php if($estudiante->entidad === $entidad): ?>
                <option selected value="<?php echo e($entidad); ?>"><?php echo e($entidad); ?></option>
                <?php else: ?>
                <option value="<?php echo e($entidad); ?>"><?php echo e($entidad); ?></option>
                <?php endif; ?>          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('entidad')): ?>
            <div class="error">
                <?php echo e($errors->first('entidad')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Region</label>
            <select class="form-control  $errors->has('region') ? 'error' : '' " name="region" id="region">
                <?php $__currentLoopData = $enumRegion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                <?php if($estudiante->region === $region): ?>
                <option value="<?php echo e($region); ?>"><?php echo e($region); ?></option>
                <?php else: ?>
                <option value="<?php echo e($region); ?>"><?php echo e($region); ?></option>
                <?php endif; ?>          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('region')): ?>
            <div class="error">
                <?php echo e($errors->first('region')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Submit" class="btn-submit">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/estudiante/editar_estudiante.blade.php ENDPATH**/ ?>