

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Contenido > Registrar datos Contenido</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('contenidoIndex')); ?>" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group form-registro">
            <label>Titulo</label>
            <input type="text" class="form-control  $errors->has('titulo') ? 'error' : '' " name="titulo" id="titulo">
            <?php if($errors->has('titulo')): ?>
            <div class="error">
                <?php echo e($errors->first('titulo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Descripción</label>
            <input type="text" class="form-control  $errors->has('descripcion') ? 'error' : '' " name="descripcion" id="descripcion">
            <?php if($errors->has('descripcion')): ?>
            <div class="error">
                <?php echo e($errors->first('descripcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Funcion</label>
            <select class="form-control  $errors->has('funcion') ? 'error' : '' " name="funcion" id="funcion">
                <?php $__currentLoopData = $enumFuncion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($funcion); ?>"><?php echo e($funcion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('funcion')): ?>
            <div class="error">
                <?php echo e($errors->first('funcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Archivo</label>
            <input type="file" class="form-control  <?php echo e($errors->has('archivo') ? 'error' : ''); ?> " name="archivo" id="archivo" accept="application/pdf">
            <?php if($errors->has('archivo')): ?>
            <div class="error">
                <?php echo e($errors->first('archivo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Registrar ➕" class="btn-opcion btn-opcion-color">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/contenido/registrar_contenido.blade.php ENDPATH**/ ?>