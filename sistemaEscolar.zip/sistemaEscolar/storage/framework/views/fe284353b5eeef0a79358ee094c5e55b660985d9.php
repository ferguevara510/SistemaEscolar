

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Estudiantes</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="line-search">
    <section>
        <form method="get" action="<?php echo e(route('estudianteProfList')); ?>">		    
            <input class="line-search-input" type="search" name="busqueda" placeholder="Nombre estudiante">		    	
            <button class="btn-opcion-buscar" type="submit">Buscar</button>
        </form>
    </section>
</div>
<div class="contenedor-tarjetas">
    <table class="table tabla-consultar">
        <thead>
            <tr class="tabla-consultar">
                <th scope="col">Nombre</th>
                <th scope="col">Apellidos</th>
                <th scope="col">Matricula</th>
                <th scope="col">Correo Institucional</th>
                <th scope="col">Licenciatura</th>
                <th scope="col">Entidad</th>
                <th scope="col">Area Academica</th>
                <th scope="col">Region</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tabla-consultar">
                <td><?php echo e($estudiante->nombreEstudiante); ?></td>
                <td><?php echo e($estudiante->apellidosEstudiante); ?></td>
                <td><?php echo e($estudiante->matricula); ?></td>
                <td><?php echo e($estudiante->correoInstitucional); ?></td>
                <td><?php echo e($estudiante->licenciatura); ?></td>
                <td><?php echo e($estudiante->entidad); ?></td>
                <td><?php echo e($estudiante->areaAcademica); ?></td>
                <td><?php echo e($estudiante->region); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/estudiante/consultar_estudiantes_profesor.blade.php ENDPATH**/ ?>