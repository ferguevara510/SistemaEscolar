

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de contenidos > Modificar datos de contenido</p>
</div>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger no-mb">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('contenidoEdit', $contenido->id)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group form-registro">
            <label>Titulo</label>
            <input value="<?php echo e($contenido->titulo); ?>" type="text" class="form-control  $errors->has('titulo') ? 'error' : '' " name="titulo" id="titulo">
            <?php if($errors->has('titulo')): ?>
            <div class="error">
                <?php echo e($errors->first('titulo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Descripción</label>
            <input value="<?php echo e($contenido->descripcion); ?>" type="text" class="form-control  $errors->has('descripcion') ? 'error' : '' " name="descripcion" id="descripcion">
            <?php if($errors->has('descripcion')): ?>
            <div class="error">
                <?php echo e($errors->first('descripcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Funcion</label>
            <select class="form-control  $errors->has('funcion') ? 'error' : '' " name="funcion" id="funcion">
                <?php $__currentLoopData = $enumFuncion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($contenido->funcion === $funcion): ?>
                <option selected value="<?php echo e($funcion); ?>"><?php echo e($funcion); ?></option>
                <?php else: ?>
                <option value="<?php echo e($funcion); ?>"><?php echo e($funcion); ?></option>
                <?php endif; ?>          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('funcion')): ?>
            <div class="error">
                <?php echo e($errors->first('funcion')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Archivo</label>
            <input value="<?php echo e($contenido->archivo); ?>" type="file" class="form-control  <?php echo e($errors->has('archivo') ? 'error' : ''); ?> " name="archivo" id="archivo" accept="application/pdf">
            <a target="_blank" href="<?php echo e(asset('/archivo/'.$contenido->archivo)); ?>"><?php echo e($contenido->archivo); ?></a>
            <?php if($errors->has('archivo')): ?>
            <div class="error">
                <?php echo e($errors->first('archivo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Modificar ✍️" class="btn-opcion btn-opcion-color">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/contenido/modificar_contenido.blade.php ENDPATH**/ ?>