

<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">

    <div>
        <p class="titulo">SEF > Lista de estudiantes > Modificar contraseña de estudiante</p>
    </div>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger no-mb">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container-registro mt-5">

        <form method="post" action="<?php echo e(route('estudianteProfesorCambiarContraseña', $estudiante->id)); ?>">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>

            <div class="form-group form-registro">
                <label>Nueva contraseña</label>
                <input type="password"
                    class="form-control  <?php echo e($errors->has('contrasena') ? 'error' : ''); ?> " name="contrasena"
                    id="nombreEstudiante">
                <?php if($errors->has('contrasena')): ?>
                    <div class="error">
                        <?php echo e($errors->first('contrasena')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="div-btn-submit">
                <input type="submit" name="send" value="Modificar ✍️" class="btn-opcion btn-opcion-color">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/estudiante/cambiar_contraseña_estudiante.blade.php ENDPATH**/ ?>