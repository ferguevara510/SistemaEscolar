

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/geogebra.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Herramienta de Graficación</p>
</div>

<div class="line-search seccion-calculadora" id="ggb-element">
    <section>
        <form method="get" action="<?php echo e(route('geogebra')); ?>"></form>
    </section>
</div>
<script src="https://www.geogebra.org/apps/deployggb.js"></script>
<script>  
    var ggbApp = new GGBApplet({"appName": "graphing", "width": 800, "height": 600, "showToolBar": true, "showAlgebraInput": true, "showMenuBar": true }, true);
      window.addEventListener("load", function() {  
        ggbApp.inject("ggb-element");
   });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/geogebra/geogebra_estudiantes.blade.php ENDPATH**/ ?>