

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div>
    <p class="titulo">SEF > Lista de practicas > <?php echo e($examen->titulo); ?></p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div class="contenedor-tarjetas">
    <table class="table tabla-consultar">
        <thead>
            <tr class="tabla-consultar">
                <th scope="col">Estudiante</th>
                <th scope="col">Calificación</th>
                <th scope="col">Fecha de realizado</th>
                <th scope="col">Habilitar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $examen->estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tabla-consultar">
                <td><?php echo e($estudiante->nombreEstudiante); ?> <?php echo e($estudiante->apellidosEstudiante); ?></td>
                <td><?php echo e($estudiante->pivot->calificacion); ?></td>
                <td><?php echo e($estudiante->pivot->fechaAplicacion); ?></td>
                <td>
                    <form method="post" action="<?php echo e(route('examenHabilitar', [$examen->id, $estudiante->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-opcion btn-opcion-color"><a class="texto-link">Habilitar</a></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Repositorios\SistemaEscolar\sistemaEscolar\resources\views/examen/consultar_examenes_estudiantes.blade.php ENDPATH**/ ?>