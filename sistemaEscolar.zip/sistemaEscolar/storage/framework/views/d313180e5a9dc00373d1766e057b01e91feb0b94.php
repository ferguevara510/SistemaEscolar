<head>
    <link rel="preload" href="<?php echo e(asset('css/footer.css')); ?>" as="style">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">>
</head>
<footer id="footer">
    <p>Todos los derechos reservados a la Universidad Veracruzana</p>
</footer>
<?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/layouts/footer.blade.php ENDPATH**/ ?>