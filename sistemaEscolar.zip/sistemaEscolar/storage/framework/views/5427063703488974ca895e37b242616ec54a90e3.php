

<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('/css/registro.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/consultar.css')); ?>" rel="stylesheet">

<div>
    <p class="titulo">SEF > Lista de Examenes > Modificar datos Examenes</p>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div class="container-registro mt-5">

    <form method="post" action="<?php echo e(route('examenEdit', $examen->id)); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group form-registro">
            <input type="hidden" value="<?php echo e($examen->profesor_id); ?>" name="profesor_id" id="profesorId">
        </div>

        <div class="form-group form-registro">
            <label>Titulo</label>
            <input value="<?php echo e($examen->titulo); ?>" type="text" class="form-control  $errors->has('titulo') ? 'error' : '' " name="titulo">
            <?php if($errors->has('titulo')): ?>
            <div class="error">
                <?php echo e($errors->first('titulo')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group form-registro">
            <label>Numero preguntas</label>
            <input value="<?php echo e($examen->numeroPreguntas); ?>" type="number" class="form-control  $errors->has('numeroPreguntas') ? 'error' : '' " name="numeroPreguntas" id="numeroPreguntas">
            <?php if($errors->has('numeroPreguntas')): ?>
            <div class="error">
                <?php echo e($errors->first('numeroPreguntas')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="div-btn-submit">
            <input type="submit" name="send" value="Modificar ✍️" class="btn-opcion btn-opcion-color">
        </div>
    </form>
    <?php if(count($preguntas) < $examen->numeroPreguntas): ?>
        <div class="btn-registrar mt-5">
            <button type="button" class="btn-opcion"><a class="texto-link" href="<?php echo e(route('preguntaIndex',$examen->id)); ?>">Agregar Pregunta ➕</a></button>
        </div>
    <?php endif; ?>
    
    <div class="contenedor-tarjetas">
    <table class="table tabla-consultar">
        <thead>
            <tr class="tabla-consultar">
                <th scope="col">Pregunta</th>
                <th scope="col">Modificar</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tabla-consultar">
                <td><?php echo e($pregunta->descripcion); ?></td>
                <td><button type="button" class="btn-opcion"><a class="texto-link" href="<?php echo e(route('preguntaShow', $pregunta->id)); ?>">Modificar ✍️</a></button></td>
                <td>
                    <form method="post" action="<?php echo e(route('preguntaDelete', $pregunta->id)); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-opcion btn-opcion-color"><a class="texto-link">Eliminar 🗑️</a></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menus.app_profesor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acdcm\Documents\Karla\sistemaEscolar\resources\views/examen/modificar_examen.blade.php ENDPATH**/ ?>