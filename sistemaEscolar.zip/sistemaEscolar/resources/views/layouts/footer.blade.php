<head>
    <link rel="preload" href="{{ asset('css/footer.css') }}" as="style">
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
</head>

<footer id="footer">
    <p>Todos los derechos reservados a la Universidad Veracruzana</p>
</footer>
